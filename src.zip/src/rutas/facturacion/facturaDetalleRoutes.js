const express = require('express');
const router = express.Router();
const facturaDetalleController = require('../../controladores/facturacion/facturaDetalleController');

// Crear detalle de factura
router.post('/factura-detalle', facturaDetalleController.crearDetalle);

// Obtener todos los detalles
router.get('/factura-detalles', facturaDetalleController.obtenerDetalles);

// Obtener detalle por ID
router.get('/factura-detalle/:id', facturaDetalleController.obtenerDetallePorId);

// Editar un detalle
router.put('/factura-detalle/:id', facturaDetalleController.editarDetalle);

// Eliminar un detalle
router.delete('/factura-detalle/:id', facturaDetalleController.eliminarDetalle);

module.exports = router;
 