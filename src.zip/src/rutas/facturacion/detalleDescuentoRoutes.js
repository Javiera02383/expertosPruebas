const express = require('express');
const router = express.Router();
const detalleDescuentoController = require('../../controladores/facturacion/detalleDescuentoController');

// Agregar descuento a factura
router.post('/detalle-descuento', detalleDescuentoController.crearDetalleDescuento);

// Obtener todos los descuentos de factura
router.get('/detalles-descuento', detalleDescuentoController.obtenerDetalles);

// Eliminar un descuento de factura
router.delete('/detalle-descuento/:idFactura/:idDescuento', detalleDescuentoController.eliminarDetalleDescuento);

module.exports = router;
