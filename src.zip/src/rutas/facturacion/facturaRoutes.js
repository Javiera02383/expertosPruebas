const express = require('express');
const router = express.Router();
const facturaController = require('../../controladores/facturacion/facturaController');


// Crear una factura
router.post('/factura', facturaController.crearFacturaCompleta);

// Obtener todas las facturas
router.get('/facturas', facturaController.obtenerFacturas);

// Obtener una factura por ID
router.get('/factura/:id', facturaController.obtenerFacturaPorId);

// Editar una factura
router.put('/factura/:id', facturaController.editarFactura);

// Anular una factura
router.put('/facturas/:id/anular', facturaController.anularFactura);


router.post('/factura-completa', facturaController.crearFacturaCompleta);

module.exports = router;
