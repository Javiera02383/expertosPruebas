const express = require('express');
const router = express.Router();
const descuentoController = require('../../controladores/facturacion/descuentoController');

// Rutas
router.get('/descuentos', descuentoController.obtenerDescuentos);
router.get('/descuento/:id', descuentoController.obtenerDescuentoPorId);
router.post('/descuento', descuentoController.validarCrear, descuentoController.crearDescuento);
router.put('/descuento/:id', descuentoController.validarEditar, descuentoController.actualizarDescuento);
router.delete('/descuento/:id', descuentoController.eliminarDescuento);

module.exports = router;
