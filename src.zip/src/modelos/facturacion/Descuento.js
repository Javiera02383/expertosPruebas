const { DataTypes } = require('sequelize');
const db = require('../../configuraciones/db');

const Descuento = db.define('Descuento', {
  idDescuento: {
    type: DataTypes.INTEGER,
    primaryKey: true
  },
  Tipo: {
    type: DataTypes.STRING(45),
    allowNull: true
  },
  Estado: {
    type: DataTypes.STRING(45),
    allowNull: true
  }
}, {
  tableName: 'descuento',
  timestamps: false
});

module.exports = Descuento;
